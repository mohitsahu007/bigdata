x = seq(-3,3,1)

funco <- function(xVe){
  if(xVe<0){
    result <- (x*x)+(2*x)+3}
  else if(xVe>=0 && xVe<2){
    result <- x+3;}
  else if(x>=2){
    result <- (x*x)+4*x-7}
  return (result)
}
funco(x)
plot(x,funco(x),"l")

ma = c(1,2,3,4,5,6,7,8,9)
mp = matrix(ma,3,3,byrow = TRUE)

falco = function(x){
  for(i in 1:ncol(x)){
    for(j in 1:nrow(x)){
      if(x[i,j]%% 2 !=0){
        x[i,j] = x[i,j] * 2
      }
    }
  }
  return (x);
}
falco(mp)
