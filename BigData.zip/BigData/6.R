x = c(1,1,3,5,2,6,-2,-1,-3)
a = matrix(x,3,3,byrow = TRUE)
a

a %*% a %*% a

a[,3] = a[,2]+a[,3]
ya <- t(a) %*% a
ya

outer(0:4,0:4,FUN = "+")