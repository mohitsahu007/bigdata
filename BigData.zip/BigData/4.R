1+sum(cumprod(seq(2,38,2)/seq(3,39,2)))

i=c(1:25)
s=sum((2^i)/i + (3^i)/(i^2))
print(s)

