zellers = function(day,month,year){
  k <- day
  y <- year%%100
  c <- floor(year/100)
  if(month<=2){
    y = y -1
    month = month + 10
  }
  else{
    month = month - 2}
  ans = ((floor(2.6 * month)+k+y+floor(y/4)+floor(c/4)-2*c)%%7)
  c("SUNDAY","MONDAY","TUESDAY","WEDNUSDAY","THURSDAY","FRIDAY","SATURDAY")[ans+1]
}

zellers(22,11,2017)

dax = c(23,24,25,26)
max = c(11,11,11,11)
yax = c(2017,2017,2017,2017)
zellers(dax,max,yax)